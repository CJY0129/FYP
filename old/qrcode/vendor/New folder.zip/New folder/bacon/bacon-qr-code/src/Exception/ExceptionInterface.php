<?php
declare(strict_types = 1);

namespace BaconQrCode\Exception;

use Throwable;

interface ExceptionInterface extends Throwable
{
}
