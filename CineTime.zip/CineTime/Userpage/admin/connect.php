<?php

    $conn = new mysqli("localhost", "root", "", "cinetime") or die ("Connection failed: %s\n". $conn -> error);
    
?>
